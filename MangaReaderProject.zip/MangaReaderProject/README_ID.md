# Manga Reader — project Android

Aplikasi Android sederhana untuk membaca halaman manga dari gambar lokal di HP.

## Fitur
- Memilih satu atau banyak gambar dari pemilih dokumen Android.
- Navigasi halaman sebelumnya/berikutnya.
- Zoom dengan gerakan pinch dan geser gambar saat diperbesar.
- Mengingat URI gambar dan halaman terakhir.
- Tidak memerlukan izin penyimpanan luas dan tidak mengirim gambar ke server.

## Cara build APK langsung dari GitHub (bisa melalui browser HP)
1. Buat akun GitHub atau masuk ke akun yang sudah ada.
2. Buat repository baru bernama `MangaReader`.
3. Unggah semua isi folder project ini ke repository, termasuk folder `.github/workflows`.
4. Buka tab **Actions** pada repository.
5. Pilih workflow **Build Manga Reader APK** lalu tekan **Run workflow**. Jika Actions belum aktif, aktifkan terlebih dahulu.
6. Tunggu sampai job selesai dengan tanda hijau.
7. Buka hasil run tersebut dan unduh artifact **Manga-Reader-debug-apk**.
8. Ekstrak ZIP artifact dan ambil `app-debug.apk`, lalu buka file itu di HP untuk memasangnya. Android mungkin meminta izin instalasi dari sumber yang kamu gunakan.

## Detail teknis
- Package: `com.mangareader.app`
- Min Android: 6.0 (API 23)
- Target/compile SDK: 35
- Build: Gradle 8.9 + Android Gradle Plugin 8.7.3
- Output yang dihasilkan workflow: `app/build/outputs/apk/debug/app-debug.apk`

## Catatan
APK belum dibangun atau diuji pada lingkungan lokal saat project ini dibuat karena lingkungan pembuat file tidak menyediakan Android SDK maupun Gradle dan tidak memiliki akses internet untuk memasangnya. Workflow GitHub Actions disertakan agar project dapat dibangun di runner yang menyediakan Android build tools.
