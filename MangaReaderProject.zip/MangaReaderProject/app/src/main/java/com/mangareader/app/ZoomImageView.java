package com.mangareader.app;

import android.content.Context;
import android.graphics.Matrix;
import android.graphics.PointF;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.widget.ImageView;

public class ZoomImageView extends ImageView {
    private final Matrix matrix = new Matrix();
    private final ScaleGestureDetector scaleDetector;
    private final PointF last = new PointF();
    private float scale = 1f;
    private boolean dragging = false;

    public ZoomImageView(Context context) { this(context, null); }
    public ZoomImageView(Context context, AttributeSet attrs) {
        super(context, attrs);
        setScaleType(ScaleType.MATRIX);
        scaleDetector = new ScaleGestureDetector(context, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
            @Override public boolean onScale(ScaleGestureDetector detector) {
                float next = Math.max(1f, Math.min(5f, scale * detector.getScaleFactor()));
                float factor = next / scale;
                matrix.postScale(factor, factor, detector.getFocusX(), detector.getFocusY());
                scale = next;
                setImageMatrix(matrix);
                return true;
            }
        });
    }

    public void resetZoom() {
        scale = 1f;
        fitImage();
    }

    @Override protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        fitImage();
    }

    @Override public void setImageURI(android.net.Uri uri) {
        super.setImageURI(uri);
        post(this::fitImage);
    }

    private void fitImage() {
        if (getDrawable() == null || getWidth() <= 0 || getHeight() <= 0) {
            matrix.reset();
            setImageMatrix(matrix);
            return;
        }
        float imageW = getDrawable().getIntrinsicWidth();
        float imageH = getDrawable().getIntrinsicHeight();
        if (imageW <= 0 || imageH <= 0) return;
        scale = Math.min((float) getWidth() / imageW, (float) getHeight() / imageH);
        float dx = (getWidth() - imageW * scale) / 2f;
        float dy = (getHeight() - imageH * scale) / 2f;
        matrix.setScale(scale, scale);
        matrix.postTranslate(dx, dy);
        setImageMatrix(matrix);
    }

    @Override public boolean onTouchEvent(MotionEvent event) {
        scaleDetector.onTouchEvent(event);
        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                last.set(event.getX(), event.getY());
                dragging = true;
                return true;
            case MotionEvent.ACTION_MOVE:
                if (dragging && scale > 1f && !scaleDetector.isInProgress()) {
                    float dx = event.getX() - last.x;
                    float dy = event.getY() - last.y;
                    matrix.postTranslate(dx, dy);
                    setImageMatrix(matrix);
                    last.set(event.getX(), event.getY());
                }
                return true;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                dragging = false;
                performClick();
                return true;
        }
        return true;
    }

    @Override public boolean performClick() {
        super.performClick();
        return true;
    }
}
