package com.mangareader.app;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {
    private static final int PICK_IMAGES = 4102;
    private final ArrayList<Uri> pages = new ArrayList<>();
    private int currentPage = 0;
    private ZoomImageView imageView;
    private TextView counter;
    private LinearLayout emptyState;
    private Button previousButton, nextButton;
    private SharedPreferences prefs;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(18, 18, 22));
        getWindow().setNavigationBarColor(Color.rgb(18, 18, 22));
        prefs = getSharedPreferences("reader", MODE_PRIVATE);
        restorePages();
        buildUi();
        showPage();
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(18, 18, 22));

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(dp(16), dp(10), dp(12), dp(10));
        header.setBackgroundColor(Color.rgb(28, 28, 34));

        TextView title = new TextView(this);
        title.setText("Manga Reader");
        title.setTextColor(Color.WHITE);
        title.setTextSize(21);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        header.addView(title, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));

        Button choose = makeButton("Pilih manga");
        choose.setOnClickListener(v -> pickImages());
        header.addView(choose);
        root.addView(header);

        FrameLayout imageArea = new FrameLayout(this);
        imageArea.setBackgroundColor(Color.rgb(10, 10, 12));
        imageView = new ZoomImageView(this);
        imageArea.addView(imageView, new FrameLayout.LayoutParams(-1, -1));

        emptyState = new LinearLayout(this);
        emptyState.setGravity(Gravity.CENTER);
        emptyState.setOrientation(LinearLayout.VERTICAL);
        emptyState.setPadding(dp(28), dp(28), dp(28), dp(28));
        TextView book = new TextView(this);
        book.setText("📚");
        book.setTextSize(48);
        book.setGravity(Gravity.CENTER);
        emptyState.addView(book);
        TextView help = new TextView(this);
        help.setText("Pilih gambar halaman manga dari HP kamu.\\nBisa memilih beberapa gambar sekaligus.");
        help.setTextColor(Color.LTGRAY);
        help.setTextSize(16);
        help.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(-1, -2);
        hp.topMargin = dp(12);
        emptyState.addView(help, hp);
        imageArea.addView(emptyState, new FrameLayout.LayoutParams(-1, -1));
        root.addView(imageArea, new LinearLayout.LayoutParams(-1, 0, 1));

        counter = new TextView(this);
        counter.setTextColor(Color.WHITE);
        counter.setTextSize(14);
        counter.setGravity(Gravity.CENTER);
        counter.setPadding(dp(8), dp(10), dp(8), dp(6));
        root.addView(counter);

        LinearLayout controls = new LinearLayout(this);
        controls.setGravity(Gravity.CENTER);
        controls.setPadding(dp(12), dp(6), dp(12), dp(14));
        controls.setBackgroundColor(Color.rgb(28, 28, 34));
        previousButton = makeButton("← Sebelumnya");
        nextButton = makeButton("Berikutnya →");
        previousButton.setOnClickListener(v -> movePage(-1));
        nextButton.setOnClickListener(v -> movePage(1));
        controls.addView(previousButton, new LinearLayout.LayoutParams(0, dp(48), 1));
        View gap = new View(this);
        controls.addView(gap, new LinearLayout.LayoutParams(dp(10), 1));
        controls.addView(nextButton, new LinearLayout.LayoutParams(0, dp(48), 1));
        root.addView(controls);
        setContentView(root);
    }

    private Button makeButton(String label) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextSize(14);
        return b;
    }

    private void pickImages() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("image/*");
        intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(intent, PICK_IMAGES);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != PICK_IMAGES || resultCode != RESULT_OK || data == null) return;
        ArrayList<Uri> selected = new ArrayList<>();
        if (data.getClipData() != null) {
            for (int i = 0; i < data.getClipData().getItemCount(); i++) {
                selected.add(data.getClipData().getItemAt(i).getUri());
            }
        } else if (data.getData() != null) {
            selected.add(data.getData());
        }
        if (selected.isEmpty()) return;
        pages.clear();
        pages.addAll(selected);
        try {
            int flags = data.getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
            for (Uri uri : pages) getContentResolver().takePersistableUriPermission(uri, flags & Intent.FLAG_GRANT_READ_URI_PERMISSION);
        } catch (Exception ignored) { }
        currentPage = 0;
        savePages();
        showPage();
        Toast.makeText(this, pages.size() + " halaman dipilih", Toast.LENGTH_SHORT).show();
    }

    private void movePage(int delta) {
        if (pages.isEmpty()) return;
        int target = currentPage + delta;
        if (target < 0 || target >= pages.size()) return;
        currentPage = target;
        savePages();
        showPage();
    }

    private void showPage() {
        boolean hasPages = !pages.isEmpty();
        emptyState.setVisibility(hasPages ? View.GONE : View.VISIBLE);
        imageView.setVisibility(hasPages ? View.VISIBLE : View.GONE);
        previousButton.setEnabled(hasPages && currentPage > 0);
        nextButton.setEnabled(hasPages && currentPage < pages.size() - 1);
        if (hasPages) {
            imageView.setImageURI(null);
            imageView.setImageURI(pages.get(currentPage));
            imageView.resetZoom();
            counter.setText("Halaman " + (currentPage + 1) + " dari " + pages.size() + "  •  Cubit untuk zoom");
        } else {
            counter.setText("Belum ada manga dipilih");
        }
    }

    private void savePages() {
        StringBuilder value = new StringBuilder();
        for (Uri uri : pages) {
            if (value.length() > 0) value.append("\n");
            value.append(uri.toString());
        }
        prefs.edit().putString("uris", value.toString()).putInt("page", currentPage).apply();
    }

    private void restorePages() {
        String stored = prefs.getString("uris", "");
        if (!stored.isEmpty()) {
            for (String line : stored.split("\n")) {
                try { pages.add(Uri.parse(line)); } catch (Exception ignored) { }
            }
        }
        currentPage = Math.max(0, Math.min(prefs.getInt("page", 0), Math.max(0, pages.size() - 1)));
    }

    private int dp(int value) { return (int)(value * getResources().getDisplayMetrics().density + 0.5f); }
}
